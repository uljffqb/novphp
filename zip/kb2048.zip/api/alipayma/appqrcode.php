<?php 
header("Content-type: text/html; charset=utf-8");
require_once 'appF2fpay.php';
//require_once 'phpqrcode.php';
if (!empty($_GET['price'])&& trim($_GET['price'])!=""){
	$f2fpay = new F2fpay();
	
	//$out_trade_no = trim($_POST['out_trade_no']);
	//$total_amount = trim($_POST['total_amount']);
	//$subject = trim($_POST['subject']);
	
    //$out_trade_no = trim($_GET['orderno']);
	$out_trade_no = build_order_no();
	$total_amount = trim($_GET['price']);
	//$total_amount = trim("0.01");
	$subject = trim($_GET['subject']);
    //$username = trim($_GET['username']);
	$body = trim($_GET['userid']);
	
	$response = 	$f2fpay->qrpay($out_trade_no,  $total_amount, $subject,$body);
	$ma = object_array($response);
require_once 'qrcode/phpqrcode.php'; 
//$value = urldecode($_GET['url']);//二维码内容 
$value = $ma["alipay_trade_precreate_response"]["qr_code"];//二维码内容 
$errorCorrectionLevel = 'L';//容错级别 
$matrixPointSize = 6;//生成图片大小 
//生成二维码图片 
$newimg = QRcode::png($value, false, $errorCorrectionLevel, $matrixPointSize); 


//输出图片 
header("Content-type: image/png");
imagepng($newimg);
    //qrcode/newqrcode.php?url=<?php echo urlencode($ma["alipay_trade_precreate_response"]["qr_code"]); ?>
?>



<?php

/*	echo '<div style="width:400px; margin:0 auto; text-align:center;">';
	echo '<p style="text-align:left;">支付宝二维码支付通道';
	echo '<span style="text-align:right; font-size:12px;">';
	echo '<a target="_blank" href="http://www.alipay.com/"><span>支付宝首页</span></a>|';
	echo '<a target="_blank" href="http://help.alipay.com/support/index_sh.htm"><span>帮助中心</span></a>';
	echo '</span></p><hr>';
	echo '';
	echo '<p>&nbsp;</p><p>收款方：<strong>KB2048</strong>&nbsp;&nbsp;&nbsp;&nbsp;订单金额：<span style="color:#f40" ;="">'.$total_amount.'</span>元</p>';
	echo '<p><img src="qrcode/newqrcode.php?url='.urlencode($ma["alipay_trade_precreate_response"]["qr_code"]).'"></p>';
	echo "<p>打开支付宝扫描进行支付，10分钟内有效！</p>";
	echo '<p style="font-size:12px;">支付宝版权所有 2011-2015 ALIPAY.COM </p>';
	echo "</div>";*/
	
	return ;
}
function object_array($array) {  
    if(is_object($array)) {  
        $array = (array)$array;  
     } 
if(is_array($array)) {  
         foreach($array as $key=>$value) {  
 
             $array[$key] = object_array($value);  
             }  
 
     }  
     return $array;  
}
//生成订单号
function build_order_no(){
    return date('Ymd').substr(implode(NULL, array_map('ord', str_split(substr(uniqid(), 7, 13), 1))), 0, 8);
}