<?php
require_once 'phpqrcode.php'; 
$value = urldecode($_GET['url']);//二维码内容 
$errorCorrectionLevel = 'L';//容错级别 
$matrixPointSize = 6;//生成图片大小 
//生成二维码图片 
$newimg = QRcode::png($value, false, $errorCorrectionLevel, $matrixPointSize); 


//输出图片 
header("Content-type: image/png");
imagepng($newimg);
