<?php 
header("Content-type: text/html; charset=utf-8");
require_once 'F2fpay.php';
//require_once 'phpqrcode.php';
if (!empty($_GET['orderno'])&& trim($_GET['orderno'])!=""){
	$f2fpay = new F2fpay();
	
	//$out_trade_no = trim($_POST['out_trade_no']);
	//$total_amount = trim($_POST['total_amount']);
	//$subject = trim($_POST['subject']);
	
	$out_trade_no = trim($_GET['orderno']);
	$total_amount = trim($_GET['price']);
	//$total_amount = trim("0.01");
	$subject = trim($_GET['subject']);
	$username = trim($_GET['username']);
	
	$response = 	$f2fpay->qrpay($out_trade_no,  $total_amount, $subject);
	$ma = object_array($response);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- saved from url=(0039)http://pay.payhere.cc/fcpay/service/p2p -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<link href="static/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="static/reset.css">
<link rel="stylesheet" href="static/pay.css">
<link rel="shortcut icon" type="image/x-icon" href="static/favicon.ico">
<title>VIP充值中心</title>
</head>
<body>
<div class="topbar">
    <div class="topbar-wrap fn-clear">
        <a href="https://cshall.alipay.com/lab/question.htm" class="topbar-link-last" target="_blank">常见问题</a>
        <span class="topbar-link-first">你好，欢迎使用支付宝支付！</span>
    </div>
</div>
<div class="container alipay_box">
    <div class="row">
        <div class="order-area">
            <div id="order" class="order order-bow">
                <div class="orderDetail-base">
                    <div class="order-extand-explain fn-clear">
						<span class="fn-left explain-trigger-area order-type-navigator" style="cursor: auto">
						<span>正在使用即时到账交易</span>
						</span>
                    </div>
                    <div class="commodity-message-row">
						
                    </div>
					<span class="payAmount-area">
					用户名：<strong class=" remark-font-22 "><?php echo $username; ?></strong>
					金额：<strong class=" amount-font-22 "><?php echo $total_amount; ?>.00</strong> 元
					</span>
                </div>
                <p class="order-ext-trigger">
                    订单详情
                </p>              
            </div>
        </div>
        <div class="cz-main bc" style=" position: relative; ">
        
            <div class="pay-left text-center">
            	<div class=" msg-box info rounded"> 1、您的支付宝如果已经成功扣款，请耐心等待3-5分钟，请不要<span style="color:red">重复</span>扫码付款<br>2、系统可能会延迟到账，如果超时请联系客服！</div>
            	<div class="pay-left"><div class="qrcode-header"><div class="ft-center">扫一扫付款（元）</div><div class="ft-center qrcode-header-money"><?php echo $total_amount; ?>.00</div></div>
            	<div class="qrcode-img-wrapper"><div data-role="qrPayImg" class="qrcode-img-area">
            		<div class="alipay_pay_info" style="position: relative;display: inline-block;">
            			<img id="qrImg" frameborder="0" src="qrcode/newqrcode.php?url=<?php echo urlencode($ma["alipay_trade_precreate_response"]["qr_code"]); ?>" width="258px" height="288px"></div></div>
            			<div class="qrcode-img-explain fn-clear"><img class="fn-left" src="static/T1bdtfXfdiXXXXXXXX.png" alt="扫一扫标识">
            				<div class="fn-left">&nbsp;&nbsp;打开手机支付宝<br>&nbsp;&nbsp;扫一扫继续付款</div></div></div><a href="https://mobile.alipay.com/index.htm" class="qrcode-downloadApp" target="_blank">首次使用请下载手机支付宝</a><div class="qrguide-area" style=" position: absolute; top: 40px; right: 50px; "><img src="static/T1ASFgXdtnXXXXXXXX.png" class="qrguide-area-img active" style="display: block;"></div></div></div>
            <div class="pay-right">
                <div class="pay_xyinfo">
                    <img src="static/pay-icon.png" alt=""><span class="xypay">支付宝支付</span><br>
                    支付宝支付安全保障，请放心支付
                </div>
            </div>
        </div>
    </div>
</div>
<div id="partner">
    <img src="static/2R3cKfrKqS.png">
</div>

</body></html>

<?php

/*	echo '<div style="width:400px; margin:0 auto; text-align:center;">';
	echo '<p style="text-align:left;">支付宝二维码支付通道';
	echo '<span style="text-align:right; font-size:12px;">';
	echo '<a target="_blank" href="http://www.alipay.com/"><span>支付宝首页</span></a>|';
	echo '<a target="_blank" href="http://help.alipay.com/support/index_sh.htm"><span>帮助中心</span></a>';
	echo '</span></p><hr>';
	echo '';
	echo '<p>&nbsp;</p><p>收款方：<strong>KB2048</strong>&nbsp;&nbsp;&nbsp;&nbsp;订单金额：<span style="color:#f40" ;="">'.$total_amount.'</span>元</p>';
	echo '<p><img src="qrcode/newqrcode.php?url='.urlencode($ma["alipay_trade_precreate_response"]["qr_code"]).'"></p>';
	echo "<p>打开支付宝扫描进行支付，10分钟内有效！</p>";
	echo '<p style="font-size:12px;">支付宝版权所有 2011-2015 ALIPAY.COM </p>';
	echo "</div>";*/
	
	return ;
}
function object_array($array) {  
    if(is_object($array)) {  
        $array = (array)$array;  
     } 
if(is_array($array)) {  
         foreach($array as $key=>$value) {  
 
             $array[$key] = object_array($value);  
             }  
 
     }  
     return $array;  
}
?>